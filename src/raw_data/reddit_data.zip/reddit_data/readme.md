 0   Unnamed: 0         50 non-null     int64    Not a feature
 1   Unnamed: 0.1       50 non-null     int64   Not a feature
 2   url_reddit_post    50 non-null     object  Url of the post
 3   title              50 non-null     object   Reddit post title 
 4   out_bound_link     38 non-null     object Link to the source website 
 6   image_links        50 non-null     object  Image links only if it contains more than one image
 7   meta_descriptions  30 non-null     object  meta description from the source website
 8   news_body          49 non-null     object  news body from the source website
 9   summary            49 non-null     object  summary of news_body
 10  keywords           50 non-null     object  keywords of news_body

keywods used :accidents in india , road accidents in india , india road accidents

