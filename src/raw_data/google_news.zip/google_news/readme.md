 0   Unnamed: 0  96 non-null     int64    Not a feature
 1   title       96 non-null     object    Title of the news
 2   desc        96 non-null     object    description
 3   date        92 non-null     object    date 
 4   datetime    46 non-null     object    date and time it publiished 
 5   link        96 non-null     object    news link to the article
 6   img         96 non-null     object    image link 
 7   media       0 non-null      float64    
 8   site        92 non-null     object     news source
 9   news_body   96 non-null     object     news body from source website
 10  keywords    96 non-null     object     keywods from news body
 11  summary     96 non-null     object     summary
  
